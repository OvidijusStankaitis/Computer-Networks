#!/bin/bash

clear
telnet ::1 20000
clear

