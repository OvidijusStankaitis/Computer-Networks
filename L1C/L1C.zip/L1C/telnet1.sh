#!/bin/bash

clear
telnet 127.0.0.1 20000
clear
